**DO NOT MODIFY ANYTHING IN THIS DIRECTORY**

This directory contains the libraries for the cbp3 framework. These libraries
have been precompiled for Linux.
